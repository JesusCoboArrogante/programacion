package org.example.Funciones

/**
 * En esta funcion imprime el resultado de las rondas ganas y de las partidas
 * @author Jesus Cobo
 * @param puntosNoa son los puntos de las rondas ganadas
 * @param puntosSoona son los puntos de las rondas ganadas
 * @param rondaNoa son las rondas ganadas
 * @param rondaSoona son las rondas ganadas
 */

fun funResultado(puntosNoa: Int, rondaNoa: Int, puntosSoona: Int, rondaSoona: Int) {
    if (puntosNoa > puntosSoona){
        println("la ganadora es Noa")
        println("Noa a ganado con $puntosNoa y a ganado $rondaNoa rondas")
        println("Soona a perdido con $puntosSoona y a ganado $rondaSoona rondas")
    }else{
        println("la ganadora es Soona")
        println("Soona a ganado con $puntosSoona y a ganado $rondaSoona rondas")
        println("Noa a perdido con $puntosNoa y a ganado $rondaNoa rondas")

    }


}

/**
 * En esta funcion se juga a piedra papel tigera
 * @return devuelve un boolean si el boolean es true punto para Noa si es false punto para Soona
 */

fun funjugar():Boolean {
    val MANOS = arrayOf("piedra", "papel", "tijera")

    var salida = false
    var punto = true


    do {
        val manoNoa = MANOS.random()
        val manoSoona = MANOS.random()
        if (manoNoa == "piedra" && manoSoona == "tijera"){

            salida = true
        }else if (manoNoa == "tijeras" && manoSoona == "papel") {

            salida = true
        }else if (manoNoa == "papel" && manoSoona == "piedra"){

            salida = true
        }else if (manoNoa == manoSoona){

            salida = false
        }else{

            salida = true
            punto = false
        }
    }while (!salida)






    return punto



}
