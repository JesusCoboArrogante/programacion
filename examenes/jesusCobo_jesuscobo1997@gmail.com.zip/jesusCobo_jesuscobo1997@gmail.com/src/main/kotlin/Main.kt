package org.example

import org.example.Funciones.funResultado
import org.example.Funciones.funjugar

/**
 * En el Main esta puesto las veces que se recorre tanto la ronda como la partida
 *
 * @author Jesus Cobo
 */
fun main() {

    var puntosNoa = 0
    var puntosSoona = 0
    val RONDA = 5
    val PARTIDAS = 3
    var puntos = true
    var rondaNoa =0
    var rondaSoona = 0
    var partida = 0
    var partidaGanadasNoa = 0
    var partidaGanadasSoona = 0



    do {
        rondaNoa = 0
        rondaSoona = 0
        do {
            partida ++
            puntos = funjugar()

            if (puntos){
                rondaNoa++
                partidaGanadasNoa++

            }else{
                rondaSoona++
                partidaGanadasSoona++

            }

            }while (rondaNoa < PARTIDAS && rondaSoona < PARTIDAS )

            if (rondaNoa > rondaSoona){

                puntosNoa++
            }else{

                puntosSoona++
            }




    }while (puntosNoa < RONDA && puntosSoona < RONDA)

    funResultado(puntosNoa,partidaGanadasNoa,puntosSoona,partidaGanadasSoona)


}

